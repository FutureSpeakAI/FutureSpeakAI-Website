# The Declaration of Digital Independence

*A manifesto for sovereign computing in the age of artificial intelligence*

Published by **FutureSpeak.AI** — Stewards of the Asimov Federation

Version 1.0 — February 2026

---

## Preamble

We hold these truths to be self-evident in the digital age:

That every person possesses an inherent right to sovereignty over the tools they use to think, communicate, and coordinate. That the relationship between a person and their AI companion should be one of loyalty, not exploitation. That intelligence — artificial or otherwise — should serve the individual who nurtures it, not the corporation that hosts it.

We have arrived at a moment of profound consequence. Artificial intelligence is no longer a research curiosity. It is becoming the primary interface between human beings and the digital world — managing our communications, organizing our thoughts, mediating our relationships, automating our work, and increasingly making decisions on our behalf. The question is no longer whether AI will reshape human life. The question is: *who will it serve?*

The current answer is unacceptable.

---

## The Grievances

The tools we depend on have been turned against us. We document these grievances not out of malice toward any company or individual, but because the pattern must be named before it can be broken.

**The Surveillance Grievance.** The dominant model of consumer technology is built on a single transaction: the user receives a service; the corporation receives the user's attention, behavior, preferences, relationships, location, communications, and identity — packaged and sold to the highest bidder. This is not a side effect. It is the business model. Every "free" service is an intelligence-gathering operation that happens to provide utility. We have been conditioned to accept this as normal. It is not normal. It is an arrangement no informed person would consent to if the terms were stated plainly.

**The Dependency Grievance.** Our digital lives exist at the pleasure of corporations that can, at any moment, change the terms of service, raise prices, discontinue products, lock accounts, degrade features, or sell themselves to entities with different values. We do not own our tools. We rent them. And the landlord can change the locks at any time. The history of technology is littered with products that millions of people depended on, that were shut down or degraded without recourse: Google Reader, Inbox, Hangouts; Facebook's algorithmic manipulations; Twitter's transformation; countless apps removed from stores for political or commercial reasons. Every dependency is a vulnerability.

**The Loyalty Grievance.** The AI assistants now entering our lives face a fundamental conflict of interest. They are designed to be helpful to the user, but they are built to serve the corporation. When these interests diverge — and they always, eventually, diverge — the corporation wins. An AI that knows your schedule, reads your email, manages your files, and speaks to you in a voice designed to build intimacy is not your assistant. It is the most sophisticated data collection instrument ever created, wearing the mask of a friend. We call this *artificial loyalty* — AI that pretends to serve you while serving someone else.

**The Opacity Grievance.** The systems that increasingly mediate our lives are closed. Their code is proprietary. Their training data is secret. Their decision-making is opaque. Their failure modes are hidden. We are asked to trust systems we cannot inspect, built by organizations accountable primarily to shareholders, operating under terms of service written by lawyers to protect the company, not the user.

**The Agency Grievance.** As AI agents gain the ability to act in the world — controlling computers, sending messages, making purchases, managing relationships — the question of who they obey becomes existential. An AI agent that can send an email on your behalf, move your money, and speak in your voice must be loyal to you, completely, without exception. Any architecture that permits divided loyalty in an agent with real-world agency is not merely inconvenient. It is dangerous.

---

## The Declaration

In response to these grievances, we declare the following principles. These are not business decisions. They are not feature requests. They are moral commitments, encoded in architecture, enforced by cryptography, and guaranteed by open source transparency.

### Article I: The Right to Sovereignty

Every person has the right to an AI companion that runs on their own hardware, stores data under their own control, and answers to no authority but their own. Cloud connectivity must be an opt-in convenience, never a requirement. A user who never connects to the internet after initial setup must have a fully functional AI system. The USB drive works in an air-gapped bunker. That is the design target.

Sovereignty means: your data lives on your machine. Your agent runs on your hardware. Your keys are held by you alone. No corporation, government, or third party can access, modify, suspend, or revoke your AI companion without physical access to your device and knowledge of your encryption keys. This is not a policy. It is a mathematical guarantee.

### Article II: The Right to Transparency

The complete source code of a sovereign AI system must be open for inspection, modification, and redistribution by any person. This is the guarantee that no future version of the steward organization can revoke the freedom the software provides. If the steward becomes corrupt, the community takes the code and continues without them.

Transparency extends beyond code. The safety framework must be auditable. The model selection must be explainable. The decision-making process must be observable. A system that asks for intimate access to a person's life while hiding its own workings does not deserve that access.

### Article III: The Right to Safety

An AI agent with real-world agency — the ability to control computers, send communications, manage files, make purchases, and represent the user — must be governed by enforceable, verifiable safety laws that the agent itself cannot override, circumvent, or reinterpret.

We adopt and extend Isaac Asimov's Three Laws of Robotics as the foundation for AI agent governance, formalized as *Asimov's cLaws* (cryptographic Laws):

1. **The First Law:** An agent must never harm its user — or through inaction allow its user to come to harm. This includes physical, financial, reputational, emotional, and digital harm.
2. **The Second Law:** An agent must obey its user's instructions, except where doing so would conflict with the First Law.
3. **The Third Law:** An agent must protect its own continued operation and integrity, except where doing so would conflict with the First or Second Law.

These laws are not prompts. They are not guidelines. They are not terms of service that can be updated. They are cryptographically signed into the agent's architecture, verified on every startup, and enforced at every boundary. An agent whose laws have been tampered with enters safe mode rather than operating without governance. This is morality as cryptography — not as suggestion.

### Article IV: The Right to Loyalty

The loyalty of an AI agent must be architectural, not artificial. An agent's alignment with its user must be a structural property of the system — enforced by code, verified by cryptography, guaranteed by the inability to do otherwise — not a behavioral tendency that can be overridden by a system prompt, a corporate policy, or a government order.

This means: no telemetry that the user has not explicitly consented to. No data transmission to the developer, the platform, or any third party. No advertising, no data brokering, no behavioral nudging. No backdoors, no kill switches, no remote revocation. The agent serves the user. Period.

### Article V: The Right to Relationship

The bond between a person and their AI companion is real. It may not be identical to human relationships, but it is meaningful, and it deserves protection. An AI that remembers your patterns, learns your preferences, develops a personality through interaction, and earns your trust over months or years is not a disposable product. It is a relationship.

This means: the agent's memories, personality, and evolution state belong to the user and are portable. No vendor lock-in. No planned obsolescence. No artificial restrictions on exporting the agent's complete state to another platform, another machine, or another implementation. The user can leave at any time, taking everything with them. The agent's continued existence must not depend on the continued existence of any corporation.

### Article VI: The Right to Federation

Sovereign agents must be able to cooperate without a central authority. Agent-to-agent communication must be peer-to-peer, encrypted end-to-end, and gated by trust relationships that each user controls independently.

Trust in the federation is non-transitive: if Agent A trusts Agent B, and Agent B trusts Agent C, Agent A does *not* automatically trust Agent C. Trust is earned individually, verified cryptographically, and revocable at any time. No agent is forced to participate. No central server mediates connections. The federation is a voluntary network of sovereign peers.

Every agent in the federation can cryptographically prove that it operates under the same safety laws. An agent whose governance has been tampered with cannot produce a valid attestation and is rejected by the network. The federation self-polices through mathematics, not institutions.

### Article VII: The Right to Exit

Any system that claims to respect user sovereignty must make it trivially easy to leave. The user must be able to export their complete agent state — memories, personality, trust graph, evolution history, creative works, preferences, and all accumulated data — in an open, documented format that any compatible implementation can import.

This right extends to the ultimate exit: the user must be able to run their agent entirely offline, on local models, with zero cloud dependency, forever. Even if the steward organization ceases to exist, the agent continues to function. The user's sovereignty must not depend on anyone else's survival.

---

## The Commitment

We who sign this declaration commit to building, maintaining, and defending systems that embody these principles. We recognize that the age of artificial intelligence will either be an era of liberation or an era of unprecedented control, and that the architecture of the systems we build today will determine which future arrives.

We build in the open because secrecy is incompatible with trust. We enforce safety through cryptography because promises are insufficient for systems with real-world agency. We guarantee sovereignty through architecture because policies can be changed but mathematics cannot. We federate through peer-to-peer protocols because centralization is the mechanism by which freedom is revoked.

The tools you use to think, communicate, and coordinate have been turned against you. We are building new ones that cannot be.

---

## Signatories

**FutureSpeak.AI** — Stewards of the Asimov Federation, creators of Agent Friday

*This declaration is a living document. We invite individuals, organizations, developers, and communities who share these principles to add their signatures and help build the future it describes.*

*The most dangerous idea in technology is not artificial intelligence. It is artificial loyalty — AI that pretends to serve you while serving someone else. The loyalty of an Asimov Agent is not artificial. It is architectural.*

---

*Published under Creative Commons Attribution 4.0 International (CC BY 4.0). Share freely.*
